using RestSharp;
using CurrencyConversionSpecflowProject.Entities;
using Newtonsoft.Json;
using NUnit.Framework;

using System.Net;

namespace CurrencyConversionSpecflowProject.StepDefinitions
{
    [Binding]
    public class CurrencyResponseStepDefinitions
    {   
        RestRequest request;
        RestResponse response;
        string api = "api";
        string Currency = "Currency";
        RestClient client = new RestClient("https://localhost:7234");

        [Given(@"Form API request with (.*) and (.*) and (.*)")]
        public void GivenFormAPIRequestWithNOKAndEURAndAmount(string curr1, string curr2, string amt)
        {
            request = new RestRequest($"{api}/{Currency}?currency1={curr1}&currency2={curr2}&Amount={amt}", Method.Get);
        }

        [When(@"User request the real time currency rates for the base currency")]
        public void WhenUserRequestTheRealTimeCurrencyRatesForTheBaseCurrency()
        {
            response = client.Execute(request);
        }

        [Then(@"response must contain the real time currency rates for the (.*) and (.*) and (.*)")]
        public void ThenResponseMustContainTheRealTimeCurrencyRatesForTheBaseCurrencyAndToCurrencyAndAmt(string curr1, string curr2, double amt)
        {
            string apiResponse = response.Content;
            CurrencyResponse curr_response = JsonConvert.DeserializeObject<CurrencyResponse>(apiResponse);
            
            Assert.IsTrue(curr_response.from == curr1);
            Assert.IsTrue(curr_response.to == curr2);
            Assert.IsTrue(curr_response.amount == amt);
            Assert.AreEqual(response.StatusCode, HttpStatusCode.OK);
        }

        [Then(@"API must return invalid response")]
        public void ThenAPIMustReturnInvalidResponse()
        {
            Assert.AreEqual(response.StatusCode, HttpStatusCode.InternalServerError);
        }

        [Then(@"response must contain all the API fields")]
        public void ThenResponseMustContainAllTheAPIFields()
        {
            string apiResponse = response.Content;
            CurrencyResponse curr_response = JsonConvert.DeserializeObject<CurrencyResponse>(apiResponse);
            Assert.IsNotEmpty(curr_response.from);
            Assert.IsNotEmpty(curr_response.to);
            Assert.IsNotEmpty(curr_response.time);

            Assert.IsNotNull(curr_response.amount);
            Assert.IsNotNull(curr_response.rate);
            Assert.IsNotNull(curr_response.convert_result);
        }

        [Then(@"amount rate and convert_result must be in numeric format")]
        public void ThenAmountRateAndConvert_ResultMustBeInNumericFormat()
        {
            string apiResponse = response.Content;
            CurrencyResponse curr_response = JsonConvert.DeserializeObject<CurrencyResponse>(apiResponse);
            
            Assert.IsTrue(curr_response.amount is double);
            Assert.IsTrue(curr_response.rate is double);
            Assert.IsTrue(curr_response.convert_result is double);

        }
    }
}