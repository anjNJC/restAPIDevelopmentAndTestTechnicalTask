﻿
using System.Collections.Generic;
using Newtonsoft.Json;

namespace CurrencyConversionSpecflowProject.Entities
{
    internal class CurrencyResponse
    {
        [JsonProperty("time")]
        public string time { get; set; }

        [JsonProperty("from")]
        public string from { get; set; }

        [JsonProperty("to")]
        public string to { get; set; }

        [JsonProperty("amount")]
        public double amount { get; set; }

        [JsonProperty("rate")]
        public double rate { get; set; }

        [JsonProperty("convert_result")]
        public double convert_result { get; set; }

    }
}
