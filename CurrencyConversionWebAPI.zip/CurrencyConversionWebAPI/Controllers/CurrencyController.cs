﻿using CurrencyConversionWebAPI.Models;

using Microsoft.AspNetCore.Mvc;

using Newtonsoft.Json.Linq;


namespace CurrencyConversionWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class CurrencyController : ControllerBase
    {

        private readonly CurrencyResponse currencyResponse;

        public CurrencyController()
        {
            currencyResponse = new CurrencyResponse();
        }

        [HttpGet]
        public async Task<CurrencyResponse> CurrencyConversionAsync(string currency1, string currency2, double Amount)
        {
            string urlPattern = String.Format("https://api.apilayer.com/fixer/latest?apikey=y1sje4opA7UKWgVCCAoSeo4U7RzPy7Hv&base={0}&symbols={1}", currency1.ToUpper(), currency2.ToUpper());
            HttpClient client = new HttpClient();
            var response = await client.GetAsync(urlPattern);
            var stringResult = await response.Content.ReadAsStringAsync();
            var details = JObject.Parse(stringResult);
            double curr_rate = (double)details["rates"].First.First;

            Console.WriteLine(curr_rate);
            double convert_res = curr_rate * Amount;

            long time_stamp = (long)details["timestamp"];

            DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeSeconds(time_stamp);
            DateTime dateTime = dateTimeOffset.DateTime;
            string time = dateTime.ToString("dd/MM/yyyy HH:mm:ss");

            Console.WriteLine(time);

            currencyResponse.time = time;
            currencyResponse.from = currency1.ToUpper();
            currencyResponse.to = currency2.ToUpper();
            currencyResponse.rate = curr_rate;
            currencyResponse.amount = Amount;
            currencyResponse.convert_result = convert_res;

            return currencyResponse;
        }
    }
}
