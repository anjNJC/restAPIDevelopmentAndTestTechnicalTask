﻿using System.ComponentModel.DataAnnotations;

namespace CurrencyConversionWebAPI.model
{
    public class Currency
    {
        [Required]
        public string Currency1 { get; set; }

        [Required]
        public string Currency2 { get; set; }

        [Required]
        public double amount { get; set; }


    }
}
