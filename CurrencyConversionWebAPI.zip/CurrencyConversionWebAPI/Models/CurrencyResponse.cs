﻿namespace CurrencyConversionWebAPI.Models
{
    public class CurrencyResponse
    {

        public string time { get; set; }

        public string from { get; set; }

        public string to { get; set; }

        public double amount { get; set; }

        public double rate { get; set; }

        public double convert_result { get; set; }

    }
}
